import React from 'react';
import Header from '../components/Header'

const Login = () => {
  return (
    <div>
      <Header />
      <h1 style={{textAlign: "center", paddingTop: "15%"}}>Login</h1>
    </div>
  )
}

export default Login
